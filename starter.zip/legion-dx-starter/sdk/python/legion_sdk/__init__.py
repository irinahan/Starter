from .client import Legion

__all__ = ["Legion"]
