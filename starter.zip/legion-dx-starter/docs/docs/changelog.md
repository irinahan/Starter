# Changelog

## 0.1.0 (2025-10-02)
- Первый публичный каркас DX: сервер, OpenAPI, SDK, CLI, Docs, CI.
