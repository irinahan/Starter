// Minimal example using fetch directly
const base = process.env.LEGION_API_URL || 'http://localhost:3000';
const key = process.env.LEGION_API_KEY || 'demo-key';

fetch(base + '/v1/health').then(r=>r.json()).then(console.log);
