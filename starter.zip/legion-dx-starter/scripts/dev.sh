#!/usr/bin/env bash
set -e
echo '🚀 Starting legion.cc Dev Environment'
( cd server && npm ci && npm run dev )
